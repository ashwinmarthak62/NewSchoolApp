package com.example.veraki.school;

/**
 * Created by veraki on 8/23/2015.
 */
public class CalendarQuickstart {
}
