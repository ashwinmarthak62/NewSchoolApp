package com.example.veraki.school.model;

/**
 * Created by veraki on 9/7/2015.
 */
public class NewsLetter {
    String issue ,preview,link;

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public String getIssue() {
        return this.issue;
    }

    public void setPreview(String preview) {
        this.preview = preview;
    }

    public String getPreview() {
        return this.preview;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getLink() {
        return this.link;
    }
}
